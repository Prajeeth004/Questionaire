Sorts questions to faculty
